public class DoubleEndedListInterface {
}
