public interface Part2<T> {

    public void addFirst(T newEntry);

    public void addLast(T newEntry);

    public T removeFirst();

    public T removeLast();

    public T getFirst();

    public T getLast();

    public void moveToEnd();



}
