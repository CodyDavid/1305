package com.company;

public class Main {

    public static void main(String[] args) {
        class Node{ //
            int data;
            Node next;
        }
         class StackUsingCircularLists {
            Node top;
            int size;
            StackUsingCircularLists(){
                size =0;
            }
            void push(int a){
                Node newNode = new Node();
                newNode.data =a;
                if (size ==0 && a!=a ){ //trying to remove duplicate i believe i mixed something up here
                    newNode.next = null;
                }else{
                    newNode.next =top;
                }
                top = newNode;
            }
// trying to have the pop to remove duplicates
            int pop(){
                int dbl = top.data;
                top = top.next;
                return dbl;
            }
            int peek(){
                return  top.data;
            }


        }

//trying to activate the class to operate,

        class main {
            void main(String args[ ])
            {
                StackUsingCircularLists w = new StackUsingCircularLists();
                w.push(20);
                w.push(20);
                w.push(25);
                w.push(40);
                System.out.println(w.pop() + " Popped from stack");

                System.out.println(w.peek());
            }
        }
    }
}
